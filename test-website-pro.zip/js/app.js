document.getElementById("testButton").addEventListener("click", () => {
  document.getElementById("result").textContent =
    "JavaScript works! ✅";
});
